# skull

Minimal boilerplate and [Basscss](http://basscss.com) theme

## Getting Started

To start fresh, clone skull into a new project and remove its git directory.

``` bash
git clone https://github.com/jxnblk/bassplate.git new-project
cd new-project
rm -rf .git
```

Use `index.html` as a starting point and edit `css/skull.css` to customize the CSS.

---

MIT License

